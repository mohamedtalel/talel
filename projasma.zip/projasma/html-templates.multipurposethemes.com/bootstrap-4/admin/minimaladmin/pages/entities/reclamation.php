<?PHP
class reclamation{
	private $IdReclamation;
	private $IdClient;
	private $DateAjout;
	private $Priorite;
	private $Sujet;
	private $Etat;
	function __construct($IdReclamation,$IdClient,$DateAjout,$Priorite,$Sujet,$Etat){
		$this->IdReclamation=$IdReclamation;
		$this->IdClient=$IdClient;
		$this->DateAjout=$DateAjout;
		$this->Priorite=$Priorite;
		$this->Sujet=$Sujet;
		$this->Etat=$Etat;
	}
	
	function getIdReclamation(){
		return $this->IdReclamation;
	}
	
	function getIdClient(){
		return $this->IdClient;
	
	}
	function getDateAjout(){
		return $this->DateAjout;
	}
	function getPriorite(){
		return $this->Priorite;
	}
	function getSujet(){
		return $this->Sujet;
	}

	function getEtat(){
		return $this->Etat;
	}

	function setIdReclamation($IdReclamation){
		$this->IdReclamation=$IdReclamation;
	}
	function setIdClient($IdClient){
		$this->IdClient=$IdClient;
	}
	function setDateAjout($DateAjout){
		$this->DateAjout=$DateAjout;
	}
	function setPriorite($Priorite){
		$this->Priorite=$Priorite;
	}
	function setSujet($Sujet){
		$this->Sujet=$Sujet;
	}
	function setEtat($Etat){
		$this->Etat=$Etat;
	}
	
}

?>