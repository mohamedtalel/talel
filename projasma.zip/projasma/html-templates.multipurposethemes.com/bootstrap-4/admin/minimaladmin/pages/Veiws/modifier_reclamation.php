<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<<?php 
	include '../core/reclamationC.php';
	include '../entities/reclamation.php';
	if (isset($_GET['IdReclamation'])){
	$reclamationC=new reclamationC();
    $result=$reclamationC->recupererReclamation($_GET['IdReclamation']);
	foreach($result as $row){
		$IdReclamation=$row['IdReclamation'];
		$IdClient=$row['IdClient'];
		$DateAjout=$row['DateAjout'];
		$Priorite=$row['Priorite'];
		$Sujet=$row['Sujet'];
		$Etat=$row['Etat'];
		

?>
<fieldset>
<form method="POST" >
	<h3 align="center" style="color:#8e172c" > VEUILLEZ RECTIFIER VOTRE RECLAMATION </h3> </br> </br>
	
<table>

<tr>
<td> <h6 align="center" style ="color:#8e172c"> Identifiant de la relcamation </h6></td>
<td><input type="number" name="IdReclamation" value="<?PHP echo $IdReclamation ?>"></td>
</tr>
<tr>
<td> <h6 align="center" style ="color:#8e172c">Identifiant du client</h6></td>
<td><input type="number" name="IdClient" value="<?PHP echo $IdClient ?>"></td>
</tr>
<tr>
<td> <h6 align="center" style ="color:#8e172c">Date d'ajout de la reclamation</h6></td>
<td><input type="date" name="DateAjout" value="<?PHP echo $DateAjout ?>"></td>
</tr>
<tr>
<td> <h6 align="center" style ="color:#8e172c">Priorite</h6></td>
<td><input type="number" name="Priorite" value="<?PHP echo $Priorite ?>"></td>
</tr>
<tr>
<td> <h6 align="center" style ="color:#8e172c">Sujet</h6></td>
<td><input type="text" name="Sujet" value="<?PHP echo $Sujet ?>"></td>
</tr>
<tr>
<td> <h6 align="center" style ="color:#8e172c">Etat</h6></td>
<td><input type="text" name="Etat" value="<?PHP echo $Etat ?>"></td>
</tr>
<tr>

<td></td>
<td><input type="submit" name="modifier" value="modifier"></td>

<tr>
<td></td>
<td><input type="hidden" name="IdReclamation" value="<?PHP echo $_GET['IdReclamation'];?>"></td>
</tr>
</table>

</form>
</fieldset>
<?PHP
	}
}
if (isset($_POST['modifier'])){
	$reclamation=new reclamation($_POST['IdReclamation'],$_POST['IdClient'],$_POST['DateAjout'],$_POST['Priorite'],$_POST['Sujet'],$_POST['Etat']);
	$reclamationC->modifierReclamation($reclamation,$_POST['IdReclamation']);
	echo $_POST['Id'];
	header('Location: affichrec.php');
}
	 ?>

</body>
</html>