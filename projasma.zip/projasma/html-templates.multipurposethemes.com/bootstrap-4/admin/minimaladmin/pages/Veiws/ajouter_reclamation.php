<?PHP
include '../core/reclamationC.php';
	include '../entities/reclamation.php';

if (isset($_POST['IdReclamation']) and isset($_POST['IdClient']) and isset($_POST['DateAjout']) and isset($_POST['Priorite']) and isset($_POST['Sujet'])and isset($_POST['Etat'])){
$reclamation1=new reclamation($_POST['IdReclamation'],$_POST['IdClient'],$_POST['DateAjout'],$_POST['Priorite'],$_POST['Sujet'],$_POST['Etat']);





$reclamation1C=new reclamationC();
$reclamation1C->ajouterReclamation($reclamation1);
header('Location: affichrec.php');

} else{
	echo "vérifier les champs";
}
//*/

?>