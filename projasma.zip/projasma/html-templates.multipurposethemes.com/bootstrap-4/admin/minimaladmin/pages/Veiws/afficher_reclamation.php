<?PHP
include 'C:\wamp64\www\back\souha\core/reclamationC.php';

$reclamation1C=new reclamationC();
?>
<table border="1" align="center" style="color:#8e172c" cellpadding="10" cellspacing="5" style="border-color: #8e172c" style="background: #8e172c">
<tr>
<td>IdReclamation</td>
<td>IdClient</td>
<td>DateAjout</td>
<td>Priorite</td>
<td>Sujet</td>
<td>Etat</td>
<td>supprimer</td>
<td>modifier</td>
</tr>

<?PHP
$listeReclamation=$reclamation1C->afficherReclamations($reclamation1C);
foreach($listeReclamation as $row){
	?>
	<tr>
	<td><?PHP echo $row['IdReclamation'];  ?></td>
	<td><?PHP echo $row['IdClient'];  ?></td>
	<td><?PHP echo $row['DateAjout']; ?></td>
	<td><?PHP echo $row['Priorite']; ?></td>
	<td><?PHP echo $row['Sujet'];    ?></td>
	<td><?PHP echo $row['Etat']; ?></td>

	<td><form method="POST" action="supprimer_reclamation.php">
	<input style="background-color:#8e172c" type="submit" name="supprimer" value="supprimer">
	<input  type="hidden" value="<?PHP echo $row['IdReclamation']; ?>" name="IdReclamation">
	</form>
	</td>
	<td><a  style="background-color:#8e172c " style="color:#fff"  href="modifier_reclamation.php?IdReclamation=<?PHP echo $row['IdReclamation']; ?>">
	Modifier </a></td>
	</tr>
	<?PHP
	
	
}
?>
</table>



