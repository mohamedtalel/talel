<?php
include '../config_db.php';
class reclamationC {

function afficherReclamation ($reclamation){
		echo "IdReclamation: ".$reclamation->getIdReclamation()."<br>";
		echo "IdClient: ".$reclamation->getIdClient()."<br>";
		echo "DateAjout: ".$reclamation->getDateAjout()."<br>";
		echo "Priorite: ".$reclamation->getPriorite()."<br>";
		echo "Sujet: ".$reclamation->getSujet()."<br>";
		echo "Etat: ".$reclamation->getEtat()."<br>";
	}

function ajouterReclamation($reclamation){
		$sql="insert into reclamation (IdReclamation,IdClient,DateAjout,Priorite,Sujet,Etat) values (:IdReclamation, :IdClient,:DateAjout,:Priorite,:Sujet, :Etat)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $IdReclamation=$reclamation->getIdReclamation();
        $IdClient=$reclamation->getIdClient();
        $DateAjout=$reclamation->getDateAjout();
        $Priorite=$reclamation->getPriorite();
        $Sujet=$reclamation->getSujet();
        $Etat=$reclamation->getEtat();
		$req->bindValue(':IdReclamation',$IdReclamation);
		$req->bindValue(':IdClient',$IdClient);
		$req->bindValue(':DateAjout',$DateAjout);
		$req->bindValue(':Priorite',$Priorite);
		$req->bindValue(':Sujet',$Sujet);
		$req->bindValue(':Etat',$Etat);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
	}
	function afficherReclamations(){

		$sql=" SELECT * from reclamation";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

	function supprimerReclamation($IdReclamation){
		$sql="DELETE FROM reclamation where IdReclamation= :IdReclamation";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':IdReclamation',$IdReclamation);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}

	function modifierReclamation($reclamation,$IdReclamation){
		$sql="UPDATE reclamation SET IdReclamation=:IdReclamation, IdClient=:IdClient,DateAjout=:DateAjout,Priorite=:Priorite,Sujet=:Sujet, Etat=:Etat WHERE IdReclamation=:IdReclamation";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$IdReclamation=$reclamation->getIdReclamation();
        $IdClient=$reclamation->getIdClient();
        $DateAjout=$reclamation->getDateAjout();
        $Priorite=$reclamation->getPriorite();
        $Sujet=$reclamation->getSujet();
        $Etat=$reclamation->getEtat();
		$datas = array(':IdReclamation'=>$IdReclamation, ':IdReclamation'=>$IdReclamation, ':IdClient'=>$IdClient,':DateAjout'=>$DateAjout,':Priorite'=>$Priorite,':Sujet'=>$Sujet, ':Etat'=>$Etat);
		$req->bindValue(':IdReclamation',$IdReclamation);
		$req->bindValue(':IdReclamation',$IdReclamation);
		$req->bindValue(':IdClient',$IdClient);
		$req->bindValue(':DateAjout',$DateAjout);
		$req->bindValue(':Priorite',$Priorite);
		$req->bindValue(':Sujet',$Sujet);
		$req->bindValue(':Etat',$Etat);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
    }
	
        function recupererReclamation($IdReclamation){
		$sql="SELECT * from reclamation where IdReclamation=$IdReclamation";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}

	function rechercherListeReclamation($IdReclamation){
		$sql="SELECT * from reclamation where IdReclamation=$IdReclamation";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
}

?>
