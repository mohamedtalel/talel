<?php
include '../config_db.php';
class reclamationC {

	function afficherReclamation ($reclamation){
		echo "IdReclamation: ".$reclamation->getIdReclamation()."<br>";
		echo "IdClient: ".$reclamation->getIdClient()."<br>";
		echo "DateAjout: ".$reclamation->getDateAjout()."<br>";
		echo "type: ".$reclamation->gettype()."<br>";

		foreach($_POST['type'] as $valeur)
		{
			echo $valeur;
		}
		echo "Sujet: ".$reclamation->getSujet()."<br>";
		echo "Etat: ".$reclamation->getEtat()."<br>";
	}

	function ajouterReclamation($reclamation){
		$sql=" INSERT INTO reclamation (IdClient,DateAjout,type,Sujet,Etat) values ( :IdClient, :DateAjout, :type, :Sujet, :Etat)";
		$db = config::getConnexion();
		try{
			$req=$db->prepare($sql);

			$IdClient=$reclamation->getIdClient();
			$DateAjout=$reclamation->getDateAjout();
			$type=$reclamation->gettype();
			$Sujet=$reclamation->getSujet();
			$Etat=$reclamation->getEtat();

			$req->bindValue(':IdClient',$IdClient);
			$req->bindValue(':DateAjout',$DateAjout);
			$req->bindValue(':type',$type);
			$req->bindValue(':Sujet',$Sujet);
			$req->bindValue(':Etat',$Etat);

			$req->execute();

		}
		catch (Exception $e){
			echo 'Erreur: '.$e->getMessage();
		}
	}
	function afficherReclamations(){

		$sql="SElECT * From reclamation";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}

	function supprimerReclamation($IdReclamation){
		$sql="DELETE FROM reclamation where IdReclamation= :IdReclamation";
		$db = config::getConnexion();
		$req=$db->prepare($sql);
		$req->bindValue(':IdReclamation',$IdReclamation);
		try{
			$req->execute();
			// header('Location: index.php');
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}

	function modifierReclamation($reclamation,$IdReclamation){
		$sql="UPDATE reclamation SET IdReclamation=:IdReclamation, IdClient=:IdClient,DateAjout=:DateAjout,type=:type,Sujet=:Sujet, Etat=:Etat WHERE IdReclamation=:IdReclamation";

		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
		try{
			$req=$db->prepare($sql);

			$IdClient=$reclamation->getIdClient();
			$DateAjout=$reclamation->getDateAjout();
			$type=$reclamation->gettype();
			$Sujet=$reclamation->getSujet();
			$Etat=$reclamation->getEtat();
			$datas = array(':IdReclamation'=>$IdReclamation, ':IdReclamation'=>$IdReclamation, ':IdClient'=>$IdClient,':DateAjout'=>$DateAjout,':type'=>$type,':Sujet'=>$Sujet, ':Etat'=>$Etat);
			$req->bindValue(':IdReclamation',$IdReclamation);
			$req->bindValue(':IdReclamation',$IdReclamation);
			$req->bindValue(':IdClient',$IdClient);
			$req->bindValue(':DateAjout',$DateAjout);
			$req->bindValue(':type',$type);
			$req->bindValue(':Sujet',$Sujet);
			$req->bindValue(':Etat',$Etat);


			$s=$req->execute();

			// header('Location: index.php');
		}
		catch (Exception $e){
			echo " Erreur ! ".$e->getMessage();
			echo " Les datas : " ;
			print_r($datas);
		}
	}

	function recupererReclamation($IdReclamation){
		$sql="SELECT * from reclamation where IdReclamation=$IdReclamation";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}

	function rechercherListeReclamation($type){
		$sql="SELECT * from employe where  type=$type";
		$db = config::getConnexion();
		try{
			$liste=$db->query($sql);
			return $liste;
		}
		catch (Exception $e){
			die('Erreur: '.$e->getMessage());
		}
	}

	function notification()
	{
		$sql="SELECT count(*) as cnt from reclamation where Etat='traitee' ";
		$db = config::getConnexion();
		$req=$db->prepare($sql);

		try{
			$req->execute();
			return $req;
		}
		catch (Exception $e)
		{
			die('Erreur: '.$e->getMessage());
		}
	}

	function notificationf()
	{
		$sql="SELECT * from reclamation where Etat='traitee' ";
		$db = config::getConnexion();
		$req=$db->prepare($sql);

		try{
			$req->execute();
			return $req;
		}
		catch (Exception $e)
		{
			die('Erreur: '.$e->getMessage());
		}
	}

}

?>
