<?PHP
class reclamation{

    private $IdClient;
    private $DateAjout;
    private $type;
    private $Sujet;
    private $Etat;
    function __construct($IdClient,$DateAjout,$type,$Sujet,$Etat){

        $this->IdClient=$IdClient;
        $this->DateAjout=$DateAjout;
        $this->type=$type;
        $this->Sujet=$Sujet;
        $this->Etat=$Etat;
    }


    function getIdClient(){
        return $this->IdClient;

    }
    function getDateAjout(){
        return $this->DateAjout;
    }
    function gettype(){
        return $this->type;
    }
    function getSujet(){
        return $this->Sujet;
    }

    function getEtat(){
        return $this->Etat;
    }


    function setIdClient($IdClient){
        $this->IdClient=$IdClient;
    }
    function setDateAjout($DateAjout){
        $this->DateAjout=$DateAjout;
    }
    function settype($type){
        $this->type=$type;
    }
    function setSujet($Sujet){
        $this->Sujet=$Sujet;
    }
    function setEtat($Etat){
        $this->Etat=$Etat;
    }

}

?>